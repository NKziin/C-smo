# Cósmo 2.0
Jogo social baseado em chat, otimizado para Render.

## Recursos
- cadastro/login com senha hash e cookie HttpOnly
- PostgreSQL opcional para persistência
- chat em tempo real e salas Chat Geral/Lore
- presença online
- perfis com avatar e bio
- bloqueio e denúncias
- base para administração/banimento
- limites e headers de segurança

## Render
Build: `npm install`
Start: `npm start`

### Persistência recomendada
Crie um PostgreSQL no Render e adicione `DATABASE_URL` ao Web Service. Defina também `JWT_SECRET` com uma string longa e aleatória.

### Administrador
Após criar o primeiro usuário, promova-o diretamente no PostgreSQL:
`UPDATE users SET role='admin' WHERE name_key='seunome';`

Nunca coloque senhas, tokens ou DATABASE_URL no código-fonte.
