# Cósmo — Jogo Social de Chat

## O que já existe
- Cadastro e login com senha armazenada com bcrypt.
- Sessão JWT.
- Chat em tempo real com Socket.IO.
- Limite de tamanho de mensagens.
- Rate limit no HTTP e anti-spam básico no chat.
- Helmet + CSP e proteção contra XSS no cliente (`textContent`).
- Interface responsiva para celular.

## Executar
1. Instale Node.js 18+.
2. Na pasta do projeto: `npm install`
3. Em produção, defina uma variável `JWT_SECRET` longa e aleatória.
4. Execute: `npm start`
5. Abra `http://localhost:3000`.

## Importante para produção
Esta versão é uma base funcional. Para um site público, troque o armazenamento em memória por PostgreSQL/Redis, use HTTPS, secret gerenciado no servidor, backup, moderação, bloqueio/denúncia e logs de segurança. Não coloque senhas ou segredos no JavaScript do navegador.
