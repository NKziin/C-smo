const path = require("path");
const http = require("http");
const crypto = require("crypto");
const express = require("express");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  maxHttpBufferSize: 16 * 1024,
  cors: { origin: false }
});

const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || crypto.randomBytes(32).toString("hex");
const users = new Map();
const messages = [];
const sockets = new Map();

app.disable("x-powered-by");
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "https://cdn.socket.io"],
      styleSrc: ["'self'"],
      connectSrc: ["'self'", "ws:", "wss:"],
      imgSrc: ["'self'", "data:"],
      objectSrc: ["'none'"],
      baseUri: ["'self'"],
      frameAncestors: ["'none'"]
    }
  }
}));
app.use(express.json({ limit: "8kb" }));
app.use(rateLimit({ windowMs: 60_000, limit: 120, standardHeaders: true, legacyHeaders: false }));
app.use(express.static(path.join(__dirname, "public")));

function cleanName(name) {
  return String(name || "").trim().replace(/\s+/g, " ").slice(0, 20);
}
function cleanMessage(message) {
  return String(message || "").trim().slice(0, 500);
}
function tokenFor(user) {
  return jwt.sign({ sub: user.id, name: user.name }, JWT_SECRET, { expiresIn: "12h" });
}
function authSocket(socket, next) {
  try {
    const token = socket.handshake.auth?.token;
    const data = jwt.verify(token, JWT_SECRET);
    const user = users.get(data.sub);
    if (!user || user.name !== data.name) return next(new Error("Sessão inválida."));
    socket.user = { id: user.id, name: user.name };
    next();
  } catch {
    next(new Error("Não autorizado."));
  }
}

app.post("/api/register", async (req, res) => {
  const name = cleanName(req.body.name);
  const password = String(req.body.password || "");
  if (!/^[A-Za-zÀ-ÿ0-9 _-]{3,20}$/.test(name))
    return res.status(400).json({ error: "Nome inválido (3–20 caracteres)." });
  if (password.length < 6 || password.length > 100)
    return res.status(400).json({ error: "A senha deve ter 6–100 caracteres." });
  const key = name.toLowerCase();
  if (users.has(key)) return res.status(409).json({ error: "Esse nome já está em uso." });
  const user = { id: crypto.randomUUID(), name, hash: await bcrypt.hash(password, 12) };
  users.set(key, user);
  res.json({ token: tokenFor(user), name: user.name });
});

app.post("/api/login", async (req, res) => {
  const name = cleanName(req.body.name);
  const password = String(req.body.password || "");
  const user = users.get(name.toLowerCase());
  if (!user || !(await bcrypt.compare(password, user.hash)))
    return res.status(401).json({ error: "Nome ou senha incorretos." });
  res.json({ token: tokenFor(user), name: user.name });
});

io.use(authSocket);

io.on("connection", socket => {
  sockets.set(socket.id, socket.user);
  socket.emit("history", messages.slice(-100));

  let lastMessageAt = 0;
  socket.on("chat:send", raw => {
    const now = Date.now();
    if (now - lastMessageAt < 700) return socket.emit("chat:error", "Aguarde um instante antes de enviar outra mensagem.");
    const text = cleanMessage(raw);
    if (!text) return;
    lastMessageAt = now;
    const msg = { id: crypto.randomUUID(), user: socket.user.name, text, at: now };
    messages.push(msg);
    if (messages.length > 500) messages.shift();
    io.emit("chat:message", msg);
  });

  socket.on("disconnect", () => sockets.delete(socket.id));
});

server.listen(PORT, () => console.log(`Cósmo Chat rodando em http://localhost:${PORT}`));